dirtycow.fasm Copyright (c) 2016, Sebastian Walz.

All rights reserved.

Copyright remains Sebastian Walz, and as such any Copyright notices in the code are not to be removed.

Redistribution and use in source, with or without modification, are permitted provided that the following
conditions are met:

1.  This program is free for commercial and non-commercial use as long as the following conditions are adhered to.

2.  It is prohibited to use this source, with or without modification, for purposes of surveillance, law enforcement, 
    military, police authorities, border patrol or counter terrorism.

3.  Redistributions of source code must retain the above copyright notice, this list of conditions
    and the following disclaimer:

      THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS »AS IS« AND ANY EXPRESS OR IMPLIED WARRANTIES,
      INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
      DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
      EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
      LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
      CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
      SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

4.  The licence and distribution terms for any publically available version or derivative of this code cannot be changed.
    i.e. this code cannot simply be copied and put under another distribution licence (including the GNU Public Licence).

This licence is a modified copy of the licence of flatassembler by Tomasz Grysztar.
